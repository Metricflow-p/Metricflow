import { Tooltip } from 'recharts'

// ── Colors ───────────────────────────────────────────────
export const COLORS = ['#CDFF50', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8']

// ── Format helpers ───────────────────────────────────────
export const fmt = (n) => `€${n.toLocaleString('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`
export const fmtPct = (n) => `${n.toFixed(1)}%`

// ── KPI Card ─────────────────────────────────────────────
export function KPICard({ label, value, sub, trend }) {
  return (
    <div style={{
      background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16,
      padding: '24px 20px', flex: '1 1 200px', minWidth: 170,
      transition: 'all 0.3s'
    }}>
      <div style={{
        fontSize: 12, color: 'var(--muted)', letterSpacing: '0.1em', textTransform: 'uppercase',
        marginBottom: 8, fontFamily: 'var(--font-mono)'
      }}>{label}</div>
      <div style={{
        fontSize: 28, fontWeight: 700, color: 'var(--accent)',
        fontFamily: 'var(--font-display)', lineHeight: 1.1
      }}>{value}</div>
      {(sub || trend !== undefined) && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
          {trend !== undefined && (
            <span style={{
              fontSize: 12, fontFamily: 'var(--font-mono)', fontWeight: 600,
              color: trend >= 0 ? 'var(--green)' : 'var(--red)'
            }}>
              {trend >= 0 ? '↑' : '↓'} {Math.abs(trend).toFixed(1)}%
            </span>
          )}
          {sub && <span style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{sub}</span>}
        </div>
      )}
    </div>
  )
}

// ── Chart Card ───────────────────────────────────────────
export function ChartCard({ title, children, span }) {
  return (
    <div style={{
      background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 16,
      padding: 24, gridColumn: span ? `span ${span}` : undefined
    }}>
      <div style={{
        fontSize: 13, color: 'var(--muted)', marginBottom: 16, letterSpacing: '0.08em',
        textTransform: 'uppercase', fontFamily: 'var(--font-mono)'
      }}>{title}</div>
      {children}
    </div>
  )
}

// ── Custom Tooltip ───────────────────────────────────────
export function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div style={{
      background: '#1A1A24', border: '1px solid var(--border)', borderRadius: 10,
      padding: '10px 14px', fontSize: 13, color: 'var(--text)', fontFamily: 'var(--font-mono)'
    }}>
      <div style={{ marginBottom: 4, color: 'var(--muted)' }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color }}>
          {p.name}: {typeof p.value === 'number'
            ? (p.value > 100 ? fmt(p.value) : p.value)
            : p.value}
        </div>
      ))}
    </div>
  )
}

// ── Insight Card ─────────────────────────────────────────
export function InsightCard({ insight }) {
  const borderColor = {
    positive: 'var(--green)',
    warning: 'var(--red)',
    info: 'var(--accent)'
  }[insight.type] || 'var(--accent)'

  return (
    <div style={{
      background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12,
      padding: '14px 18px', display: 'flex', alignItems: 'flex-start', gap: 12,
      fontSize: 14, lineHeight: 1.6, borderLeft: `3px solid ${borderColor}`
    }}>
      <span style={{ fontSize: 18, flexShrink: 0 }}>{insight.icon}</span>
      <span>{insight.text}</span>
    </div>
  )
}

// ── Section Label ────────────────────────────────────────
export function SectionLabel({ children }) {
  return (
    <div style={{
      fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--accent)',
      fontFamily: 'var(--font-mono)', marginBottom: 14, fontWeight: 500
    }}>{children}</div>
  )
}

// ── Button ───────────────────────────────────────────────
export function Button({ children, variant = 'primary', onClick, disabled, style = {}, ...props }) {
  const styles = {
    primary: {
      background: 'var(--accent)', color: 'var(--bg)', border: 'none',
      fontWeight: 700
    },
    ghost: {
      background: 'transparent', color: 'var(--text)',
      border: '1px solid var(--border)', fontWeight: 500
    },
    danger: {
      background: 'transparent', color: 'var(--red)',
      border: '1px solid var(--red)', fontWeight: 500
    }
  }

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: '14px 28px', borderRadius: 12, fontSize: 15, cursor: disabled ? 'not-allowed' : 'pointer',
        fontFamily: 'var(--font-display)', transition: 'all 0.25s', opacity: disabled ? 0.5 : 1,
        ...styles[variant],
        ...style
      }}
      {...props}
    >
      {children}
    </button>
  )
}

// ── Loading Spinner ──────────────────────────────────────
export function Spinner({ size = 20, color = 'var(--accent)' }) {
  return (
    <div style={{
      width: size, height: size, border: `2px solid ${color}33`,
      borderTop: `2px solid ${color}`, borderRadius: '50%',
      animation: 'spin 0.8s linear infinite', display: 'inline-block'
    }}>
      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  )
}
