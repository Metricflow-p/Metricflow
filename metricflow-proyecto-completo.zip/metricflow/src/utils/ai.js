const API_URL = 'https://api.anthropic.com/v1/messages'
const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY || ''

export async function generateAIReport(data) {
  const summary = {
    periodo: `${data.monthlyData[0]?.mes} a ${data.monthlyData[data.monthlyData.length - 1]?.mes}`,
    ingresos_total: `€${data.totalIngresos.toFixed(2)}`,
    beneficio_total: `€${data.totalBeneficio.toFixed(2)}`,
    unidades_vendidas: data.totalUnidades,
    margen_medio: `${data.margen.toFixed(1)}%`,
    crecimiento: `${data.growth.toFixed(1)}%`,
    productos: data.productData.slice(0, 6).map(p => ({
      nombre: p.producto,
      ingresos: `€${p.ingresos.toFixed(2)}`,
      unidades: p.unidades,
      margen: p.ingresos > 0 ? `${((p.beneficio / p.ingresos) * 100).toFixed(1)}%` : '0%'
    })),
    canales: data.channelData.map(c => ({
      nombre: c.name,
      ingresos: `€${c.value.toFixed(2)}`,
      beneficio: `€${c.beneficio.toFixed(2)}`
    })),
    categorias: data.categoryData.map(c => ({
      nombre: c.name,
      ingresos: `€${c.value.toFixed(2)}`
    })),
    tendencia_mensual: data.monthlyData.map(m => ({
      mes: m.mes,
      ingresos: `€${m.ingresos.toFixed(2)}`,
      unidades: m.unidades
    }))
  }

  // If no API key, return a placeholder report
  if (!API_KEY) {
    return generateLocalReport(data)
  }

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1200,
        messages: [{
          role: 'user',
          content: `Eres un consultor senior de e-commerce con 15 años de experiencia. Analiza estos datos de ventas y genera un informe ejecutivo en español con estas secciones:

RESUMEN DE SITUACIÓN (2-3 frases directas sobre el estado del negocio)

HALLAZGOS CLAVE
1. [hallazgo más importante con números]
2. [segundo hallazgo con números]  
3. [tercer hallazgo con números]

PLAN DE ACCIÓN — PRÓXIMAS 2 SEMANAS
1. [acción concreta y específica]
2. [acción concreta y específica]
3. [acción concreta y específica]

ALERTA
[Si hay algo preocupante, menciónalo aquí. Si no, omite esta sección.]

Sé directo, específico y usa números siempre. No uses markdown, asteriscos ni formato especial. Solo texto plano con saltos de línea.

Datos del negocio:
${JSON.stringify(summary, null, 2)}`
        }]
      })
    })

    if (!response.ok) {
      const err = await response.text()
      console.error('API error:', err)
      return generateLocalReport(data)
    }

    const result = await response.json()
    return result.content?.map(b => b.text || '').join('') || generateLocalReport(data)
  } catch (err) {
    console.error('AI report error:', err)
    return generateLocalReport(data)
  }
}

// ── Fallback report without API ──────────────────────────

function generateLocalReport(data) {
  const lines = []

  lines.push('RESUMEN DE SITUACIÓN')
  lines.push('')
  if (data.growth > 5) {
    lines.push(`El negocio muestra una tendencia positiva con un crecimiento del ${data.growth.toFixed(1)}% en el periodo analizado. Los ingresos totales alcanzan €${data.totalIngresos.toFixed(0)} con un margen del ${data.margen.toFixed(1)}%. La base de productos y canales está diversificada.`)
  } else if (data.growth < -5) {
    lines.push(`El negocio muestra señales de alerta con una caída del ${Math.abs(data.growth).toFixed(1)}% en ingresos. A pesar de generar €${data.totalIngresos.toFixed(0)} en total, la tendencia descendente requiere acción inmediata.`)
  } else {
    lines.push(`El negocio se mantiene estable con €${data.totalIngresos.toFixed(0)} en ingresos totales y un margen del ${data.margen.toFixed(1)}%. Es un buen momento para optimizar y experimentar con nuevas estrategias.`)
  }

  lines.push('')
  lines.push('HALLAZGOS CLAVE')
  lines.push('')
  lines.push(`1. "${data.topProduct}" lidera las ventas y debería ser el centro de tu estrategia de marketing. Representa la mayor fuente de ingresos del negocio.`)
  lines.push('')
  lines.push(`2. ${data.topChannel} es el canal con mayor rendimiento. Concentrar aquí el presupuesto publicitario maximizaría el retorno sobre la inversión.`)
  lines.push('')
  lines.push(`3. "${data.bestMarginProduct}" tiene el mejor margen de beneficio del catálogo. Promocionarlo activamente generaría más beneficio neto por cada euro invertido en publicidad.`)

  lines.push('')
  lines.push('PLAN DE ACCIÓN — PRÓXIMAS 2 SEMANAS')
  lines.push('')
  lines.push(`1. Lanza una campaña específica para "${data.topProduct}" en ${data.topChannel} con un presupuesto test de €50-100. Mide el ROAS antes de escalar.`)
  lines.push('')
  lines.push(`2. Crea un bundle combinando "${data.topProduct}" con "${data.bestMarginProduct}" a un precio con descuento del 10%. Esto sube el ticket medio y mueve stock del producto con mejor margen.`)
  lines.push('')
  lines.push(`3. Revisa el catálogo y evalúa eliminar los productos con menor rotación. Liberar stock y simplificar la oferta puede mejorar márgenes y reducir costes operativos.`)

  if (data.margen < 35) {
    lines.push('')
    lines.push('ALERTA')
    lines.push('')
    lines.push(`El margen medio del ${data.margen.toFixed(1)}% está por debajo del umbral saludable para e-commerce (35-45%). Revisa tus costes de adquisición y evalúa una subida de precios del 5-10% en los productos menos sensibles al precio.`)
  }

  return lines.join('\n')
}
