import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || ''
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || ''

export const supabase = supabaseUrl && supabaseKey
  ? createClient(supabaseUrl, supabaseKey)
  : null

// ── Waitlist ──────────────────────────────────────────────
export async function addToWaitlist(email) {
  if (!supabase) {
    console.log('[DEV] Waitlist signup:', email)
    return { success: true, dev: true }
  }

  try {
    const { data, error } = await supabase
      .from('waitlist')
      .insert([{
        email: email.toLowerCase().trim(),
        signed_up_at: new Date().toISOString(),
        source: window.location.href
      }])

    if (error) {
      // Duplicate email
      if (error.code === '23505') {
        return { success: true, duplicate: true }
      }
      throw error
    }
    return { success: true, data }
  } catch (err) {
    console.error('Waitlist error:', err)
    return { success: false, error: err.message }
  }
}

// ── Analytics Events (optional) ──────────────────────────
export async function trackEvent(event, metadata = {}) {
  if (!supabase) {
    console.log('[DEV] Event:', event, metadata)
    return
  }

  try {
    await supabase
      .from('events')
      .insert([{
        event,
        metadata,
        created_at: new Date().toISOString()
      }])
  } catch (err) {
    console.error('Track error:', err)
  }
}
