// ── Process raw CSV rows into analytics ──────────────────

export function processData(raw) {
  const rows = raw
    .filter(r => r.fecha && r.cantidad && r.precio_unitario)
    .map(r => ({
      ...r,
      cantidad: Number(r.cantidad) || 0,
      precio_unitario: Number(r.precio_unitario) || 0,
      coste: Number(r.coste) || 0,
      ingreso: (Number(r.cantidad) || 0) * (Number(r.precio_unitario) || 0),
      beneficio: (Number(r.cantidad) || 0) * ((Number(r.precio_unitario) || 0) - (Number(r.coste) || 0)),
      mes: r.fecha?.substring(0, 7),
    }))

  if (rows.length === 0) return null

  // ── KPIs ──
  const totalIngresos = rows.reduce((s, r) => s + r.ingreso, 0)
  const totalBeneficio = rows.reduce((s, r) => s + r.beneficio, 0)
  const totalUnidades = rows.reduce((s, r) => s + r.cantidad, 0)
  const margen = totalIngresos > 0 ? (totalBeneficio / totalIngresos) * 100 : 0
  const ticketMedio = rows.length > 0 ? totalIngresos / rows.length : 0

  // ── Monthly trends ──
  const byMonth = {}
  rows.forEach(r => {
    if (!byMonth[r.mes]) byMonth[r.mes] = { mes: r.mes, ingresos: 0, beneficio: 0, unidades: 0, transacciones: 0 }
    byMonth[r.mes].ingresos += r.ingreso
    byMonth[r.mes].beneficio += r.beneficio
    byMonth[r.mes].unidades += r.cantidad
    byMonth[r.mes].transacciones += 1
  })
  const monthlyData = Object.values(byMonth).sort((a, b) => a.mes.localeCompare(b.mes))

  // ── Growth rate ──
  const growth = monthlyData.length >= 2
    ? ((monthlyData[monthlyData.length - 1].ingresos - monthlyData[0].ingresos) / monthlyData[0].ingresos) * 100
    : 0

  // ── Products ──
  const byProduct = {}
  rows.forEach(r => {
    const key = r.producto || 'Sin nombre'
    if (!byProduct[key]) byProduct[key] = { producto: key, ingresos: 0, unidades: 0, beneficio: 0 }
    byProduct[key].ingresos += r.ingreso
    byProduct[key].unidades += r.cantidad
    byProduct[key].beneficio += r.beneficio
  })
  const productData = Object.values(byProduct).sort((a, b) => b.ingresos - a.ingresos)

  // ── Categories ──
  const byCategory = {}
  rows.forEach(r => {
    const key = r.categoria || 'Sin categoría'
    if (!byCategory[key]) byCategory[key] = { name: key, value: 0, beneficio: 0 }
    byCategory[key].value += r.ingreso
    byCategory[key].beneficio += r.beneficio
  })
  const categoryData = Object.values(byCategory).sort((a, b) => b.value - a.value)

  // ── Channels ──
  const byChannel = {}
  rows.forEach(r => {
    const key = r.canal || 'Directo'
    if (!byChannel[key]) byChannel[key] = { name: key, value: 0, beneficio: 0, unidades: 0 }
    byChannel[key].value += r.ingreso
    byChannel[key].beneficio += r.beneficio
    byChannel[key].unidades += r.cantidad
  })
  const channelData = Object.values(byChannel).sort((a, b) => b.value - a.value)

  // ── Top performers ──
  const topProduct = productData[0]?.producto || '—'
  const topChannel = channelData[0]?.name || '—'
  const bestMarginProduct = [...Object.values(byProduct)]
    .filter(p => p.ingresos > 0)
    .sort((a, b) => (b.beneficio / b.ingresos) - (a.beneficio / a.ingresos))[0]?.producto || '—'
  const worstProduct = productData[productData.length - 1]?.producto || '—'

  return {
    totalIngresos, totalBeneficio, totalUnidades, margen, ticketMedio, growth,
    monthlyData, productData, categoryData, channelData,
    topProduct, topChannel, bestMarginProduct, worstProduct,
    rows, totalRows: rows.length
  }
}

// ── Generate automatic insights ──────────────────────────

export function generateInsights(data) {
  const insights = []

  if (data.growth > 5) {
    insights.push({
      type: 'positive', icon: '📈',
      text: `Ingresos creciendo un ${data.growth.toFixed(1)}% entre el primer y último mes. La tendencia es claramente positiva.`
    })
  } else if (data.growth < -5) {
    insights.push({
      type: 'warning', icon: '⚠️',
      text: `Ingresos cayendo un ${Math.abs(data.growth).toFixed(1)}%. Revisa tu estrategia de captación y retención urgentemente.`
    })
  } else {
    insights.push({
      type: 'info', icon: '📊',
      text: `Ingresos estables (${data.growth > 0 ? '+' : ''}${data.growth.toFixed(1)}%). Buen momento para experimentar con nuevos canales.`
    })
  }

  insights.push({
    type: 'info', icon: '⭐',
    text: `"${data.topProduct}" es tu producto estrella. Genera la mayor parte de los ingresos. Considera crear variantes o bundles.`
  })

  insights.push({
    type: 'info', icon: '📱',
    text: `${data.topChannel} es tu canal más rentable. Aumenta la inversión aquí para maximizar ROI.`
  })

  insights.push({
    type: data.margen > 40 ? 'positive' : 'warning',
    icon: '💰',
    text: `Margen medio del ${data.margen.toFixed(1)}%. ${data.margen > 40
      ? 'Es un margen saludable para e-commerce.'
      : 'Está por debajo del 40% — busca optimizar costes o ajustar precios.'}`
  })

  insights.push({
    type: 'info', icon: '🎯',
    text: `"${data.bestMarginProduct}" tiene el mejor margen de beneficio. Priorízalo en campañas de pago.`
  })

  if (data.productData.length > 3) {
    const bottom = data.productData[data.productData.length - 1]
    insights.push({
      type: 'warning', icon: '🔍',
      text: `"${bottom.producto}" tiene el menor rendimiento (${((bottom.ingresos / data.totalIngresos) * 100).toFixed(1)}% de ingresos). Evalúa si merece espacio en catálogo.`
    })
  }

  return insights
}

// ── Demo data ────────────────────────────────────────────

export const DEMO_CSV = `fecha,producto,categoria,cantidad,precio_unitario,coste,canal
2025-01-05,Camiseta Oversize,Ropa,12,29.99,12.50,Instagram
2025-01-05,Zapatillas Urban,Calzado,5,89.99,35.00,Web
2025-01-08,Bolso Minimal,Accesorios,8,45.00,18.00,Instagram
2025-01-10,Camiseta Oversize,Ropa,15,29.99,12.50,TikTok
2025-01-12,Gorra Vintage,Accesorios,20,19.99,6.00,Web
2025-01-15,Zapatillas Urban,Calzado,7,89.99,35.00,Instagram
2025-01-18,Sudadera Logo,Ropa,10,59.99,22.00,TikTok
2025-01-20,Bolso Minimal,Accesorios,6,45.00,18.00,Web
2025-01-22,Pantalón Cargo,Ropa,9,49.99,20.00,Instagram
2025-01-25,Camiseta Oversize,Ropa,18,29.99,12.50,Web
2025-01-28,Zapatillas Urban,Calzado,4,89.99,35.00,TikTok
2025-02-01,Gorra Vintage,Accesorios,25,19.99,6.00,Instagram
2025-02-03,Sudadera Logo,Ropa,14,59.99,22.00,Web
2025-02-05,Bolso Minimal,Accesorios,11,45.00,18.00,TikTok
2025-02-08,Pantalón Cargo,Ropa,7,49.99,20.00,Web
2025-02-10,Camiseta Oversize,Ropa,22,29.99,12.50,Instagram
2025-02-12,Zapatillas Urban,Calzado,9,89.99,35.00,Web
2025-02-15,Gorra Vintage,Accesorios,15,19.99,6.00,TikTok
2025-02-18,Sudadera Logo,Ropa,8,59.99,22.00,Instagram
2025-02-20,Bolso Minimal,Accesorios,13,45.00,18.00,Web
2025-02-22,Pantalón Cargo,Ropa,11,49.99,20.00,TikTok
2025-02-25,Camiseta Oversize,Ropa,20,29.99,12.50,Web
2025-02-28,Zapatillas Urban,Calzado,6,89.99,35.00,Instagram
2025-03-02,Gorra Vintage,Accesorios,30,19.99,6.00,Web
2025-03-05,Sudadera Logo,Ropa,16,59.99,22.00,TikTok
2025-03-08,Bolso Minimal,Accesorios,9,45.00,18.00,Instagram
2025-03-10,Pantalón Cargo,Ropa,13,49.99,20.00,Web
2025-03-12,Camiseta Oversize,Ropa,25,29.99,12.50,TikTok
2025-03-15,Zapatillas Urban,Calzado,11,89.99,35.00,Web
2025-03-18,Gorra Vintage,Accesorios,18,19.99,6.00,Instagram
2025-03-20,Sudadera Logo,Ropa,12,59.99,22.00,Web
2025-03-22,Bolso Minimal,Accesorios,15,45.00,18.00,TikTok
2025-03-25,Pantalón Cargo,Ropa,8,49.99,20.00,Instagram
2025-03-28,Camiseta Oversize,Ropa,28,29.99,12.50,Web
2025-03-30,Zapatillas Urban,Calzado,8,89.99,35.00,TikTok`
