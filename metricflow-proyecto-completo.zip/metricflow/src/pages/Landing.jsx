import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { addToWaitlist, trackEvent } from '../utils/supabase'
import { SectionLabel } from '../components/UI'

// ── Animated counter ─────────────────────────────────────
function AnimNum({ target, prefix = '', suffix = '' }) {
  const [val, setVal] = useState(0)
  const ref = useRef(null)
  const [go, setGo] = useState(false)

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setGo(true) }, { threshold: 0.5 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  useEffect(() => {
    if (!go) return
    let n = 0
    const step = target / 40
    const t = setInterval(() => {
      n += step
      if (n >= target) { setVal(target); clearInterval(t) }
      else setVal(Math.floor(n))
    }, 30)
    return () => clearInterval(t)
  }, [go, target])

  return <span ref={ref}>{prefix}{val.toLocaleString('es-ES')}{suffix}</span>
}

export default function Landing() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [sending, setSending] = useState(false)
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const h = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', h, { passive: true })
    trackEvent('page_view', { page: 'landing' })
    return () => window.removeEventListener('scroll', h)
  }, [])

  const handleWaitlist = async () => {
    if (!email || !email.includes('@')) return
    setSending(true)
    const result = await addToWaitlist(email)
    if (result.success) {
      setSubmitted(true)
      trackEvent('waitlist_signup', { email })
    }
    setSending(false)
  }

  const features = [
    { icon: '⚡', title: 'Análisis instantáneo', desc: 'Sube un CSV y en menos de 10 segundos tienes un dashboard completo con KPIs, gráficos y métricas de rendimiento.', color: '#FFD93D' },
    { icon: '🤖', title: 'Informes con IA', desc: 'La IA analiza tus datos y genera recomendaciones personalizadas: qué productos potenciar, en qué canal invertir, dónde recortar.', color: '#CDFF50' },
    { icon: '📊', title: 'Tendencias y patrones', desc: 'Detecta estacionalidad, productos en declive y oportunidades de crecimiento antes que tu competencia.', color: '#4ECDC4' },
    { icon: '🔌', title: 'Conecta tu tienda', desc: 'Integración directa con Shopify, WooCommerce y Amazon. Sin exportar CSVs manualmente nunca más.', color: '#FF6B6B' },
    { icon: '📧', title: 'Reportes automáticos', desc: 'Recibe cada lunes un informe semanal en tu email con los cambios clave y las acciones recomendadas.', color: '#DDA0DD' },
    { icon: '🔒', title: 'Tus datos son tuyos', desc: 'No almacenamos tus datos de ventas. Se procesan en tiempo real y se borran. Cumplimiento RGPD total.', color: '#45B7D1' },
  ]

  const steps = [
    { num: '01', title: 'Sube tus datos', desc: 'Arrastra tu CSV de ventas o conecta directamente tu tienda Shopify o WooCommerce.', time: '10 seg' },
    { num: '02', title: 'Análisis automático', desc: 'Nuestro motor procesa tus datos al instante: KPIs, patrones, segmentación y anomalías.', time: '5 seg' },
    { num: '03', title: 'Recibe tu informe', desc: 'La IA genera un informe ejecutivo con las 3 acciones más impactantes para esta semana.', time: '15 seg' },
  ]

  const pricing = [
    { name: 'Starter', price: '0', period: 'para siempre', desc: 'Para probar sin compromiso', features: ['1 análisis al mes', 'Dashboard básico', 'Exportar PNG', 'Datos CSV'], cta: 'Empezar gratis' },
    { name: 'Pro', price: '19', period: '/mes', desc: 'Para vendedores serios', features: ['Análisis ilimitados', 'Informes IA ejecutivos', 'Exportar PDF profesional', 'Comparativas mensuales', 'Soporte prioritario'], cta: 'Probar 14 días gratis', featured: true, badge: 'Más popular' },
    { name: 'Business', price: '49', period: '/mes', desc: 'Para equipos y agencias', features: ['Todo en Pro', 'Conectar Shopify / WooCommerce', 'Reportes automáticos semanales', 'Multi-tienda (hasta 10)', 'API access', 'Onboarding personalizado'], cta: 'Contactar ventas' },
  ]

  const testimonials = [
    { name: 'Laura M.', role: 'Shopify · Moda', text: 'Antes tardaba 2 horas en Excel. Ahora en 30 segundos tengo claro qué producto empujar y en qué canal.', avatar: '👩‍💼' },
    { name: 'Carlos R.', role: 'Amazon · Electrónica', text: 'El informe IA me sugirió eliminar un producto. Liberé stock y subí un 15% la facturación.', avatar: '👨‍💻' },
    { name: 'Ana G.', role: 'Agencia · 12 clientes', text: 'Genero informes mensuales para mis clientes. Lo que antes llevaba un día ahora son 10 minutos.', avatar: '👩‍🎨' },
    { name: 'Pablo S.', role: 'WooCommerce · Alimentación', text: 'La detección de estacionalidad me ahorró una compra de stock que habría sido un desastre.', avatar: '👨‍🍳' },
  ]

  return (
    <div>
      {/* ── NAV ── */}
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        background: scrollY > 60 ? 'var(--bg)' + 'E8' : 'transparent',
        backdropFilter: scrollY > 60 ? 'blur(20px)' : 'none',
        borderBottom: `1px solid ${scrollY > 60 ? 'var(--border)' : 'transparent'}`,
        transition: 'all 0.3s'
      }}>
        <div style={{ maxWidth: 1080, margin: '0 auto', padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em', cursor: 'pointer' }} onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <span style={{ color: 'var(--accent)' }}>Metric</span>Flow
          </div>
          <div style={{ display: 'flex', gap: 28, alignItems: 'center' }} className="hide-mobile">
            {['Producto', 'Cómo funciona', 'Precios'].map((l, i) => (
              <a key={l} href={`#${['features', 'how', 'pricing'][i]}`}
                style={{ color: 'var(--muted)', fontSize: 14, fontFamily: 'var(--font-mono)', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--text)'}
                onMouseLeave={e => e.target.style.color = 'var(--muted)'}
              >{l}</a>
            ))}
            <button onClick={() => navigate('/app')} style={{
              padding: '10px 22px', background: 'var(--accent)', color: 'var(--bg)', border: 'none',
              borderRadius: 10, fontSize: 13, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-display)'
            }}>Probar demo</button>
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <div style={{ position: 'relative', minHeight: '100vh', display: 'flex', alignItems: 'center', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', width: 500, height: 500, borderRadius: '50%',
          background: 'radial-gradient(circle, #CDFF5018, transparent 70%)',
          top: -100, right: -100, animation: 'glow 6s ease-in-out infinite'
        }} />
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.03,
          backgroundImage: 'linear-gradient(var(--text) 1px, transparent 1px), linear-gradient(90deg, var(--text) 1px, transparent 1px)',
          backgroundSize: '60px 60px'
        }} />

        <div style={{ maxWidth: 1080, margin: '0 auto', padding: '140px 24px 100px', position: 'relative', width: '100%' }}>
          <div style={{ maxWidth: 680, animation: 'fadeUp 0.8s ease' }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 8, background: 'var(--surface)',
              border: '1px solid var(--border)', borderRadius: 100, padding: '8px 18px 8px 10px',
              fontSize: 13, color: 'var(--muted)', marginBottom: 32, fontFamily: 'var(--font-mono)'
            }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--green)', display: 'inline-block', boxShadow: '0 0 8px var(--green)' }} />
              Beta abierta — plazas limitadas
            </div>

            <h1 style={{ fontSize: 'clamp(40px, 6vw, 72px)', fontWeight: 900, lineHeight: 1.05, letterSpacing: '-0.03em', marginBottom: 24 }}>
              Tu e-commerce{' '}
              <span style={{ color: 'var(--accent)', textShadow: '0 0 60px var(--accent-dim)' }}>analizado</span>
              <br />en segundos
            </h1>

            <p style={{ fontSize: 19, lineHeight: 1.7, color: 'var(--muted)', maxWidth: 520, marginBottom: 40, fontWeight: 300 }}>
              Sube tus datos de ventas y obtén un informe ejecutivo con métricas clave, tendencias e insights accionables generados por inteligencia artificial.
            </p>

            <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
              <a href="#waitlist" style={{
                padding: '16px 36px', background: 'var(--accent)', color: 'var(--bg)', borderRadius: 12,
                fontSize: 16, fontWeight: 700, display: 'inline-block', transition: 'transform 0.2s'
              }}>Empezar gratis →</a>
              <button onClick={() => navigate('/app')} style={{
                padding: '16px 36px', background: 'transparent', color: 'var(--text)',
                border: '1px solid var(--border)', borderRadius: 12, fontSize: 16, fontWeight: 500,
                cursor: 'pointer', fontFamily: 'var(--font-display)', transition: 'all 0.2s'
              }}>Ver demo en vivo</button>
            </div>
          </div>
        </div>
      </div>

      {/* ── SOCIAL PROOF ── */}
      <div style={{ borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)', padding: '40px 24px', background: 'var(--surface)' }}>
        <div style={{ maxWidth: 1080, margin: '0 auto', display: 'flex', justifyContent: 'center', gap: 56, flexWrap: 'wrap' }}>
          {[
            { value: <AnimNum target={2847} suffix="+" />, label: 'Informes generados' },
            { value: <AnimNum target={340} />, label: 'Tiendas activas' },
            { value: <AnimNum target={23} suffix="h" />, label: 'Ahorro medio/mes' },
            { value: '4.9★', label: 'Valoración media' },
          ].map((s, i) => (
            <div key={i} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 30, fontWeight: 800, color: 'var(--accent)' }}>{s.value}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4, fontFamily: 'var(--font-mono)' }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── FEATURES ── */}
      <section id="features" style={{ padding: '100px 24px', maxWidth: 1080, margin: '0 auto' }}>
        <SectionLabel>Producto</SectionLabel>
        <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.02em', marginBottom: 16, lineHeight: 1.1 }}>
          Todo lo que necesitas para<br /><span style={{ color: 'var(--accent)' }}>tomar mejores decisiones</span>
        </h2>
        <p style={{ color: 'var(--muted)', fontSize: 17, maxWidth: 500, marginBottom: 56, lineHeight: 1.6, fontWeight: 300 }}>
          Deja de intuir y empieza a decidir con datos. MetricFlow transforma tus números en acciones concretas.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 18 }}>
          {features.map((f, i) => (
            <div key={i} style={{
              background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 20,
              padding: '36px 28px', transition: 'all 0.3s', cursor: 'default'
            }}>
              <div style={{
                width: 52, height: 52, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 26, background: f.color + '12', marginBottom: 20
              }}>{f.icon}</div>
              <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 10 }}>{f.title}</h3>
              <p style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.7, fontWeight: 300 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section id="how" style={{ background: 'var(--surface)', padding: '100px 24px' }}>
        <div style={{ maxWidth: 1080, margin: '0 auto' }}>
          <SectionLabel>Cómo funciona</SectionLabel>
          <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.02em', marginBottom: 60, lineHeight: 1.1 }}>
            De datos crudos a decisiones<br /><span style={{ color: 'var(--accent)' }}>en tres pasos</span>
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 48 }}>
            {steps.map((s, i) => (
              <div key={i} style={{ display: 'flex', gap: 28, alignItems: 'flex-start', position: 'relative' }}>
                {i < 2 && <div style={{ position: 'absolute', left: 27, top: 56, bottom: -44, width: 2, background: 'var(--border)' }} />}
                <div style={{
                  width: 56, height: 56, borderRadius: 16, background: 'var(--card)',
                  border: '2px solid var(--accent-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, fontSize: 18, fontWeight: 700, color: 'var(--accent)', fontFamily: 'var(--font-mono)'
                }}>{s.num}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, flexWrap: 'wrap', gap: 8 }}>
                    <h3 style={{ fontSize: 22, fontWeight: 700 }}>{s.title}</h3>
                    <span style={{
                      fontSize: 12, color: 'var(--green)', fontFamily: 'var(--font-mono)',
                      background: '#34D39915', padding: '4px 12px', borderRadius: 100
                    }}>~{s.time}</span>
                  </div>
                  <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.7, fontWeight: 300, maxWidth: 500 }}>{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ── */}
      <section id="pricing" style={{ padding: '100px 24px', maxWidth: 1080, margin: '0 auto' }}>
        <SectionLabel>Precios</SectionLabel>
        <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.02em', marginBottom: 16, lineHeight: 1.1 }}>
          Empieza gratis,<br /><span style={{ color: 'var(--accent)' }}>escala cuando quieras</span>
        </h2>
        <p style={{ color: 'var(--muted)', fontSize: 17, maxWidth: 480, marginBottom: 56, lineHeight: 1.6, fontWeight: 300 }}>
          Sin compromisos. Cancela cuando quieras. Todos los planes incluyen 14 días de prueba.
        </p>
        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          {pricing.map((p, i) => (
            <div key={i} style={{
              background: 'var(--card)', border: `1px solid ${p.featured ? '#CDFF5066' : 'var(--border)'}`,
              borderRadius: 24, padding: '40px 32px', flex: '1 1 260px', minWidth: 260, position: 'relative',
              boxShadow: p.featured ? '0 0 60px var(--accent-dim)' : 'none'
            }}>
              {p.badge && (
                <div style={{
                  position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)',
                  background: 'var(--accent)', color: 'var(--bg)', fontSize: 11, fontWeight: 700,
                  padding: '5px 16px', borderRadius: 100, letterSpacing: '0.05em', textTransform: 'uppercase',
                  fontFamily: 'var(--font-mono)'
                }}>{p.badge}</div>
              )}
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--accent)', marginBottom: 4, fontFamily: 'var(--font-mono)' }}>{p.name}</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 4 }}>
                <span style={{ fontSize: 48, fontWeight: 900, letterSpacing: '-0.03em' }}>€{p.price}</span>
                <span style={{ fontSize: 14, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{p.period}</span>
              </div>
              <p style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 28, fontWeight: 300 }}>{p.desc}</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 32 }}>
                {p.features.map((f, j) => (
                  <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14 }}>
                    <span style={{ color: 'var(--green)' }}>✓</span>
                    <span style={{ fontWeight: 300 }}>{f}</span>
                  </div>
                ))}
              </div>
              <a href="#waitlist" style={{
                display: 'block', textAlign: 'center', padding: '14px', borderRadius: 12, fontSize: 14, fontWeight: 600,
                background: p.featured ? 'var(--accent)' : 'transparent',
                color: p.featured ? 'var(--bg)' : 'var(--text)',
                border: p.featured ? 'none' : '1px solid var(--border)',
                transition: 'all 0.2s'
              }}>{p.cta}</a>
            </div>
          ))}
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <div style={{ borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)', padding: '80px 0', background: 'var(--surface)', overflow: 'hidden' }}>
        <div style={{ padding: '0 24px', maxWidth: 1080, margin: '0 auto 40px' }}>
          <SectionLabel>Testimonios</SectionLabel>
          <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: '-0.02em' }}>
            Lo que dicen nuestros <span style={{ color: 'var(--accent)' }}>early adopters</span>
          </h2>
        </div>
        <div style={{ display: 'flex', gap: 18, padding: '0 24px', overflowX: 'auto' }}>
          {testimonials.map((t, i) => (
            <div key={i} style={{
              background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16,
              padding: 28, minWidth: 300, flexShrink: 0
            }}>
              <p style={{ fontSize: 15, lineHeight: 1.7, marginBottom: 20, fontWeight: 300, fontStyle: 'italic' }}>"{t.text}"</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 12, background: 'var(--card)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20
                }}>{t.avatar}</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── WAITLIST CTA ── */}
      <section id="waitlist" style={{ padding: '100px 24px 60px', maxWidth: 1080, margin: '0 auto' }}>
        <div style={{
          background: 'linear-gradient(135deg, var(--card), var(--surface))',
          border: '1px solid #CDFF5033', borderRadius: 28, padding: '64px 40px', textAlign: 'center',
          position: 'relative', overflow: 'hidden'
        }}>
          <div style={{
            position: 'absolute', width: 300, height: 300, borderRadius: '50%',
            background: 'radial-gradient(circle, #CDFF5010, transparent 70%)', top: -80, right: -80
          }} />

          {!submitted ? (
            <>
              <div style={{ fontSize: 48, marginBottom: 16, animation: 'float 4s ease-in-out infinite' }}>🚀</div>
              <h2 style={{ fontSize: 36, fontWeight: 800, letterSpacing: '-0.02em', marginBottom: 12 }}>
                Consigue acceso anticipado
              </h2>
              <p style={{ color: 'var(--muted)', fontSize: 16, maxWidth: 440, margin: '0 auto 36px', lineHeight: 1.6, fontWeight: 300 }}>
                Únete a la lista de espera y prueba MetricFlow gratis. Las primeras 100 cuentas tendrán el plan Pro gratis durante 3 meses.
              </p>
              <div style={{ display: 'flex', gap: 12, maxWidth: 480, margin: '0 auto', flexWrap: 'wrap', justifyContent: 'center' }}>
                <input
                  type="email" value={email}
                  onChange={e => setEmail(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleWaitlist()}
                  placeholder="tu@email.com"
                  style={{
                    flex: '1 1 240px', padding: '16px 20px', background: 'var(--bg)', color: 'var(--text)',
                    border: '1px solid var(--border)', borderRadius: 12, fontSize: 15,
                    fontFamily: 'var(--font-mono)'
                  }}
                />
                <button onClick={handleWaitlist} disabled={sending} style={{
                  padding: '16px 32px', background: 'var(--accent)', color: 'var(--bg)', border: 'none',
                  borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: 'pointer',
                  fontFamily: 'var(--font-display)', opacity: sending ? 0.6 : 1, whiteSpace: 'nowrap'
                }}>{sending ? 'Enviando...' : 'Reservar plaza'}</button>
              </div>
              <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 14, fontFamily: 'var(--font-mono)' }}>
                Sin spam. Solo te avisamos cuando esté listo.
              </p>
            </>
          ) : (
            <div style={{ animation: 'fadeUp 0.5s ease' }}>
              <div style={{ fontSize: 56, marginBottom: 16 }}>🎉</div>
              <h2 style={{ fontSize: 32, fontWeight: 800, marginBottom: 12 }}>¡Estás dentro!</h2>
              <p style={{ color: 'var(--muted)', fontSize: 16, maxWidth: 400, margin: '0 auto', lineHeight: 1.6, fontWeight: 300 }}>
                Te hemos guardado plaza. Recibirás un email en <span style={{ color: 'var(--accent)' }}>{email}</span> cuando tu acceso esté listo.
              </p>
              <button onClick={() => navigate('/app')} style={{
                marginTop: 24, padding: '14px 32px', background: 'var(--accent)', color: 'var(--bg)',
                border: 'none', borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: 'pointer',
                fontFamily: 'var(--font-display)'
              }}>Mientras tanto, prueba la demo →</button>
            </div>
          )}
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ borderTop: '1px solid var(--border)', padding: '40px 24px' }}>
        <div style={{ maxWidth: 1080, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 4 }}>
              <span style={{ color: 'var(--accent)' }}>Metric</span>Flow
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>
              © 2026 MetricFlow. Hecho en España 🇪🇸
            </div>
          </div>
          <div style={{ display: 'flex', gap: 24 }}>
            {['Privacidad', 'Términos', 'Contacto'].map(l => (
              <a key={l} href="#" style={{ fontSize: 13, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{l}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  )
}
