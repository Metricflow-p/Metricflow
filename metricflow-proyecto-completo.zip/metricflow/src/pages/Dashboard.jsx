import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import Papa from 'papaparse'
import {
  BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts'
import { processData, generateInsights, DEMO_CSV } from '../utils/analytics'
import { generateAIReport } from '../utils/ai'
import { trackEvent } from '../utils/supabase'
import { KPICard, ChartCard, ChartTooltip, InsightCard, COLORS, fmt } from '../components/UI'

export default function Dashboard() {
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const [insights, setInsights] = useState([])
  const [csvText, setCsvText] = useState('')
  const [loading, setLoading] = useState(false)
  const [aiLoading, setAiLoading] = useState(false)
  const [aiReport, setAiReport] = useState('')
  const [animIn, setAnimIn] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const fileRef = useRef()

  useEffect(() => {
    if (data) setTimeout(() => setAnimIn(true), 50)
    else setAnimIn(false)
  }, [data])

  const analyze = (text) => {
    setLoading(true)
    setAiReport('')
    setTimeout(() => {
      const parsed = Papa.parse(text.trim(), { header: true, skipEmptyLines: true })
      const processed = processData(parsed.data)
      if (!processed) { setLoading(false); return }
      setData(processed)
      setInsights(generateInsights(processed))
      setLoading(false)
      trackEvent('analysis_complete', { rows: processed.totalRows })
    }, 600)
  }

  const handleFile = (file) => {
    if (!file) return
    const reader = new FileReader()
    reader.onload = (e) => {
      setCsvText(e.target.result)
      analyze(e.target.result)
    }
    reader.readAsText(file)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    if (file && (file.name.endsWith('.csv') || file.type === 'text/csv')) {
      handleFile(file)
    }
  }

  const handleAIReport = async () => {
    setAiLoading(true)
    trackEvent('ai_report_requested')
    const report = await generateAIReport(data)
    setAiReport(report)
    setAiLoading(false)
  }

  // ── Upload screen ──────────────────────────────────────
  if (!data) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 32 }}>
        <div style={{ position: 'absolute', top: 24, left: 24 }}>
          <span style={{ fontSize: 22, fontWeight: 800, cursor: 'pointer' }} onClick={() => navigate('/')}>
            <span style={{ color: 'var(--accent)' }}>Metric</span>Flow
          </span>
        </div>

        <div style={{ animation: 'float 4s ease-in-out infinite', fontSize: 48, marginBottom: 16 }}>📊</div>
        <h1 style={{ fontSize: 36, fontWeight: 800, textAlign: 'center', marginBottom: 8, letterSpacing: '-0.02em' }}>
          Analiza tus ventas
        </h1>
        <p style={{ color: 'var(--muted)', fontSize: 16, textAlign: 'center', maxWidth: 450, marginBottom: 40, lineHeight: 1.6, fontFamily: 'var(--font-mono)' }}>
          Sube tu CSV de ventas o prueba con datos de ejemplo
        </p>

        <div style={{
          background: 'var(--card)', border: `2px dashed ${dragOver ? 'var(--accent)' : 'var(--border)'}`,
          borderRadius: 20, padding: 36, width: '100%', maxWidth: 560,
          transition: 'border-color 0.2s', animation: 'fadeUp 0.6s ease'
        }}
          onDragOver={e => { e.preventDefault(); setDragOver(true) }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
        >
          <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
            <button onClick={() => fileRef.current?.click()} style={{
              flex: 1, padding: '14px 20px', background: 'var(--accent)', color: 'var(--bg)', border: 'none',
              borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-display)'
            }}>📁 Subir CSV</button>
            <button onClick={() => { setCsvText(DEMO_CSV); analyze(DEMO_CSV) }} style={{
              flex: 1, padding: '14px 20px', background: 'transparent', color: 'var(--text)',
              border: '1px solid var(--border)', borderRadius: 12, fontSize: 15, fontWeight: 500,
              cursor: 'pointer', fontFamily: 'var(--font-display)'
            }}>▶ Ver demo</button>
            <input ref={fileRef} type="file" accept=".csv" onChange={e => handleFile(e.target.files[0])} style={{ display: 'none' }} />
          </div>

          <textarea
            value={csvText}
            onChange={e => setCsvText(e.target.value)}
            placeholder={'Pega tus datos CSV aquí o arrastra un archivo...\n\nFormato:\nfecha,producto,categoria,cantidad,precio_unitario,coste,canal'}
            style={{
              width: '100%', minHeight: 150, background: 'var(--bg)', color: 'var(--text)',
              border: '1px solid var(--border)', borderRadius: 12, padding: 16, fontSize: 13,
              fontFamily: 'var(--font-mono)', resize: 'vertical', lineHeight: 1.6
            }}
          />

          {csvText && (
            <button onClick={() => analyze(csvText)} style={{
              width: '100%', marginTop: 16, padding: 14, background: 'var(--accent)', color: 'var(--bg)',
              border: 'none', borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: 'pointer',
              fontFamily: 'var(--font-display)'
            }}>{loading ? 'Analizando...' : '🚀 Analizar datos'}</button>
          )}
        </div>

        <div style={{ marginTop: 40, display: 'flex', gap: 28, flexWrap: 'wrap', justifyContent: 'center' }}>
          {[
            { icon: '📄', text: 'CSV con columnas: fecha, producto, categoria, cantidad, precio_unitario, coste, canal' },
            { icon: '🔒', text: 'Tus datos no se almacenan — se procesan en tu navegador' },
          ].map((h, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>
              <span>{h.icon}</span> {h.text}
            </div>
          ))}
        </div>
      </div>
    )
  }

  // ── Dashboard ──────────────────────────────────────────
  return (
    <div style={{ minHeight: '100vh', padding: '24px 20px' }}>
      <div style={{ maxWidth: 920, margin: '0 auto' }}>

        {/* Header */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28,
          opacity: animIn ? 1 : 0, transform: animIn ? 'none' : 'translateY(20px)', transition: 'all 0.4s'
        }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 24, fontWeight: 800 }}>
              <span style={{ color: 'var(--accent)' }}>Metric</span>Flow
            </h1>
            <span style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>
              {data.totalRows} registros · {data.monthlyData.length} meses
            </span>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={() => { setData(null); setCsvText(''); setAiReport('') }} style={{
              padding: '10px 18px', background: 'transparent', color: 'var(--text)',
              border: '1px solid var(--border)', borderRadius: 10, fontSize: 13, cursor: 'pointer',
              fontFamily: 'var(--font-mono)', transition: 'all 0.2s'
            }}>← Nuevo</button>
            <button onClick={() => navigate('/')} style={{
              padding: '10px 18px', background: 'transparent', color: 'var(--muted)',
              border: '1px solid var(--border)', borderRadius: 10, fontSize: 13, cursor: 'pointer',
              fontFamily: 'var(--font-mono)'
            }}>Inicio</button>
          </div>
        </div>

        {/* KPIs */}
        <div style={{
          display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 24,
          opacity: animIn ? 1 : 0, transition: 'all 0.5s 0.1s'
        }}>
          <KPICard label="Ingresos totales" value={fmt(data.totalIngresos)} trend={data.growth} />
          <KPICard label="Beneficio neto" value={fmt(data.totalBeneficio)} />
          <KPICard label="Unidades vendidas" value={data.totalUnidades.toLocaleString('es-ES')} />
          <KPICard label="Margen medio" value={`${data.margen.toFixed(1)}%`} sub={data.margen > 40 ? 'Saludable' : 'Mejorable'} />
        </div>

        {/* Charts */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24,
          opacity: animIn ? 1 : 0, transition: 'all 0.5s 0.2s'
        }}>
          <ChartCard title="Evolución mensual" span={2}>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={data.monthlyData}>
                <defs>
                  <linearGradient id="gI" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#CDFF50" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#CDFF50" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1C1C2E" />
                <XAxis dataKey="mes" stroke="#5E5E72" fontSize={12} fontFamily="IBM Plex Mono" />
                <YAxis stroke="#5E5E72" fontSize={11} fontFamily="IBM Plex Mono" tickFormatter={v => `€${(v / 1000).toFixed(1)}k`} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="ingresos" stroke="#CDFF50" fill="url(#gI)" strokeWidth={2.5} name="Ingresos" />
                <Area type="monotone" dataKey="beneficio" stroke="#4ECDC4" fill="transparent" strokeWidth={2} strokeDasharray="5 5" name="Beneficio" />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Ingresos por producto">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={data.productData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1C1C2E" />
                <XAxis type="number" stroke="#5E5E72" fontSize={11} fontFamily="IBM Plex Mono" tickFormatter={v => `€${(v / 1000).toFixed(1)}k`} />
                <YAxis dataKey="producto" type="category" stroke="#5E5E72" fontSize={11} fontFamily="IBM Plex Mono" width={110} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="ingresos" name="Ingresos" radius={[0, 6, 6, 0]}>
                  {data.productData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Distribución por categoría">
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={data.categoryData} cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={4} dataKey="value">
                  {data.categoryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 16, marginTop: 8 }}>
              {data.categoryData.map((c, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontFamily: 'var(--font-mono)', color: 'var(--muted)' }}>
                  <div style={{ width: 10, height: 10, borderRadius: 3, background: COLORS[i % COLORS.length] }} />
                  {c.name}
                </div>
              ))}
            </div>
          </ChartCard>

          <ChartCard title="Rendimiento por canal" span={2}>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={data.channelData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1C1C2E" />
                <XAxis dataKey="name" stroke="#5E5E72" fontSize={12} fontFamily="IBM Plex Mono" />
                <YAxis stroke="#5E5E72" fontSize={11} fontFamily="IBM Plex Mono" tickFormatter={v => `€${(v / 1000).toFixed(1)}k`} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="value" name="Ingresos" fill="#CDFF50" radius={[6, 6, 0, 0]} />
                <Bar dataKey="beneficio" name="Beneficio" fill="#4ECDC4" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Insights */}
        <div style={{ marginBottom: 24, opacity: animIn ? 1 : 0, transition: 'all 0.5s 0.3s' }}>
          <div style={{
            fontSize: 13, color: 'var(--muted)', letterSpacing: '0.08em', textTransform: 'uppercase',
            fontFamily: 'var(--font-mono)', marginBottom: 12
          }}>Insights automáticos</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {insights.map((ins, i) => <InsightCard key={i} insight={ins} />)}
          </div>
        </div>

        {/* AI Report */}
        <div style={{ opacity: animIn ? 1 : 0, transition: 'all 0.5s 0.4s', marginBottom: 40 }}>
          {!aiReport ? (
            <button onClick={handleAIReport} disabled={aiLoading} style={{
              width: '100%', padding: 16,
              background: aiLoading ? 'var(--card)' : 'linear-gradient(135deg, #CDFF50, #A8D63A)',
              color: aiLoading ? 'var(--muted)' : 'var(--bg)',
              border: aiLoading ? '1px solid var(--border)' : 'none',
              borderRadius: 14, fontSize: 15, fontWeight: 700, cursor: aiLoading ? 'wait' : 'pointer',
              fontFamily: 'var(--font-display)', transition: 'all 0.2s'
            }}>
              {aiLoading ? '🤖 Generando informe ejecutivo con IA...' : '🤖 Generar informe ejecutivo con IA'}
            </button>
          ) : (
            <div style={{ background: 'var(--card)', border: '1px solid #CDFF5033', borderRadius: 16, padding: 28 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
                <span style={{ fontSize: 22 }}>🤖</span>
                <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--accent)' }}>Informe ejecutivo IA</span>
              </div>
              <div style={{
                fontSize: 14, lineHeight: 1.8, fontFamily: 'var(--font-mono)', whiteSpace: 'pre-wrap'
              }}>{aiReport}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
